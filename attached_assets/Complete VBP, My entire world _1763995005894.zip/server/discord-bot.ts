import * as dotenv from "dotenv";
dotenv.config();
import { Client, GatewayIntentBits, SlashCommandBuilder, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ButtonStyle } from 'discord.js';
import { storage } from './storage';
import { cultivationService } from './cultivation';
import { missionService } from './missions';
import { cultivationRealms } from '@shared/schema';

export class CultivationBot {
  private client: Client;
  private readonly TOKEN = process.env.DISCORD_BOT_TOKEN;
  export const bot = new CultivationBot(process.env.DISCORD_TOKEN!);
  constructor(private TOKEN: string) {
  this.client = new Client({ intents: [GatewayIntentBits.Guilds] });
}
  constructor() {
    this.client = new Client({
      intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildMembers,
      ],
    });
    
    this.setupEventHandlers();
    this.setupCommands();
  }
  
  private setupEventHandlers() {
    this.client.once('ready', () => {
      console.log(`Bot is ready! Logged in as ${this.client.user?.tag}`);
    });
    
    this.client.on('guildMemberAdd', async (member) => {
      await this.handleNewMember(member);
    });
    
    this.client.on('messageCreate', async (message) => {
      if (message.author.bot) return;
      await this.handleChatXp(message);
    });
    
    this.client.on('interactionCreate', async (interaction) => {
      if (!interaction.isChatInputCommand()) return;
      await this.handleSlashCommand(interaction);
    });
  }
  
  private async setupCommands() {
    const commands = [
      new SlashCommandBuilder()
        .setName('profile')
        .setDescription('View your cultivation profile'),
      
      new SlashCommandBuilder()
        .setName('cultivate')
        .setDescription('Attempt to advance your cultivation realm'),
      
      new SlashCommandBuilder()
        .setName('spar')
        .setDescription('Challenge another cultivator to a sparring match')
        .addUserOption(option =>
          option.setName('opponent')
            .setDescription('The cultivator you want to challenge')
            .setRequired(true)),
      
      new SlashCommandBuilder()
        .setName('faction')
        .setDescription('Faction management')
        .addSubcommand(subcommand =>
          subcommand.setName('create')
            .setDescription('Create a new faction')
            .addStringOption(option =>
              option.setName('name')
                .setDescription('Name of the faction')
                .setRequired(true))
            .addStringOption(option =>
              option.setName('description')
                .setDescription('Description of the faction')
                .setRequired(false)))
        .addSubcommand(subcommand =>
          subcommand.setName('join')
            .setDescription('Join an existing faction')
            .addStringOption(option =>
              option.setName('name')
                .setDescription('Name of the faction to join')
                .setRequired(true)))
        .addSubcommand(subcommand =>
          subcommand.setName('leave')
            .setDescription('Leave your current faction'))
        .addSubcommand(subcommand =>
          subcommand.setName('info')
            .setDescription('View faction information')),
      
      new SlashCommandBuilder()
        .setName('shop')
        .setDescription('View the cultivation shop'),
      
      new SlashCommandBuilder()
        .setName('inventory')
        .setDescription('View your inventory'),
      
      new SlashCommandBuilder()
        .setName('missions')
        .setDescription('View your active missions'),
      
      new SlashCommandBuilder()
        .setName('leaderboard')
        .setDescription('View the cultivation leaderboard'),
      
      new SlashCommandBuilder()
        .setName('rebirth')
        .setDescription('Undergo rebirth to start anew with bonuses'),
      
      // Sect Master commands
      new SlashCommandBuilder()
        .setName('sectmaster')
        .setDescription('Sect Master divine powers')
        .addSubcommand(subcommand =>
          subcommand.setName('grant')
            .setDescription('Grant cultivation levels to a disciple')
            .addUserOption(option =>
              option.setName('user')
                .setDescription('The disciple to grant levels to')
                .setRequired(true))
            .addIntegerOption(option =>
              option.setName('levels')
                .setDescription('Number of levels to grant')
                .setRequired(true)))
        .addSubcommand(subcommand =>
          subcommand.setName('banish')
            .setDescription('Banish a cultivator from the sect')
            .addUserOption(option =>
              option.setName('user')
                .setDescription('The cultivator to banish')
                .setRequired(true)))
        .addSubcommand(subcommand =>
          subcommand.setName('event')
            .setDescription('Start a sect-wide event')
            .addStringOption(option =>
              option.setName('type')
                .setDescription('Type of event')
                .setRequired(true)
                .addChoices(
                  { name: 'Double XP', value: 'double_xp' },
                  { name: 'Faction War', value: 'faction_war' },
                  { name: 'Treasure Hunt', value: 'treasure_hunt' }
                ))),
    ];
    
    // Register commands
    this.client.on('ready', async () => {
      const guild = this.client.guilds.cache.first();
      if (guild) {
        await guild.commands.set(commands);
        console.log('Slash commands registered successfully');
      }
    });
  }
  
  private async handleNewMember(member: any) {
    const serverId = member.guild.id;
    const settings = await storage.getServerSettings(serverId);
    
    if (settings?.welcomeChannelId) {
      const channel = await this.client.channels.fetch(settings.welcomeChannelId);
      if (channel && channel.isTextBased()) {
        const embed = new EmbedBuilder()
          .setTitle('🌟 Welcome to the Cultivation Sect!')
          .setDescription(`Greetings, ${member.displayName}! Your journey to immortality begins now.`)
          .setColor(0x00D4FF)
          .addFields(
            { name: '🗡️ Getting Started', value: 'Use `/profile` to view your cultivation status' },
            { name: '💎 Earning Void Crystals', value: 'Chat in the server to gain XP and crystals' },
            { name: '⚔️ Battle System', value: 'Challenge others with `/spar @user`' },
            { name: '🏛️ Factions', value: 'Join or create factions with `/faction`' }
          )
          .setThumbnail(member.user.displayAvatarURL())
          .setTimestamp();
        
        await channel.send({ embeds: [embed] });
      }
    }
    
    // Create user profile
    try {
      await storage.createUser({
        discordId: member.user.id,
        username: member.displayName,
        avatar: member.user.displayAvatarURL(),
        serverId: serverId,
        realm: 'Connate',
        level: 1,
        xp: 0,
        power: 100,
        defense: 100,
        agility: 100,
        wisdom: 100,
        voidCrystals: 100, // Starting crystals
      });
    } catch (error) {
      console.error('Error creating user profile:', error);
    }
  }
  
  private async handleChatXp(message: any) {
    const user = await storage.getUserByDiscordId(message.author.id, message.guild.id);
    if (!user) return;
    
    const result = await cultivationService.gainChatXp(user.id, message.content.length);
    
    if (result.levelUp) {
      const embed = new EmbedBuilder()
        .setTitle('🌟 Level Up!')
        .setDescription(`${message.author.displayName} has advanced to Level ${result.user.level}!`)
        .setColor(0xFFD700)
        .addFields(
          { name: 'Realm', value: result.user.realm, inline: true },
          { name: 'Power', value: result.user.power.toString(), inline: true },
          { name: 'XP', value: `${result.user.xp}/${cultivationService.getXpRequirement(result.user.level + 1)}`, inline: true }
        )
        .setThumbnail(message.author.displayAvatarURL())
        .setTimestamp();
      
      await message.reply({ embeds: [embed] });
    }
  }
  
  private async handleSlashCommand(interaction: any) {
    const { commandName } = interaction;
    
    try {
      switch (commandName) {
        case 'profile':
          await this.handleProfileCommand(interaction);
          break;
        case 'cultivate':
          await this.handleCultivateCommand(interaction);
          break;
        case 'spar':
          await this.handleSparCommand(interaction);
          break;
        case 'faction':
          await this.handleFactionCommand(interaction);
          break;
        case 'shop':
          await this.handleShopCommand(interaction);
          break;
        case 'inventory':
          await this.handleInventoryCommand(interaction);
          break;
        case 'missions':
          await this.handleMissionsCommand(interaction);
          break;
        case 'leaderboard':
          await this.handleLeaderboardCommand(interaction);
          break;
        case 'rebirth':
          await this.handleRebirthCommand(interaction);
          break;
        case 'sectmaster':
          await this.handleSectMasterCommand(interaction);
          break;
        default:
          await interaction.reply({ content: 'Unknown command!', ephemeral: true });
      }
    } catch (error) {
      console.error('Error handling slash command:', error);
      await interaction.reply({ content: 'An error occurred while processing your command.', ephemeral: true });
    }
  }
  
  private async handleProfileCommand(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered. Please wait a moment and try again.', ephemeral: true });
      return;
    }
    
    const userWithDetails = await storage.getUserWithDetails(user.id);
    const nextLevelXp = cultivationService.getXpRequirement(user.level + 1);
    
    const embed = new EmbedBuilder()
      .setTitle(`${user.username}'s Cultivation Profile`)
      .setColor(0x00D4FF)
      .setThumbnail(interaction.user.displayAvatarURL())
      .addFields(
        { name: '🏔️ Realm', value: user.realm, inline: true },
        { name: '⭐ Level', value: user.level.toString(), inline: true },
        { name: '💎 Void Crystals', value: user.voidCrystals.toString(), inline: true },
        { name: '🔥 Power', value: user.power.toString(), inline: true },
        { name: '🛡️ Defense', value: user.defense.toString(), inline: true },
        { name: '⚡ Agility', value: user.agility.toString(), inline: true },
        { name: '🧠 Wisdom', value: user.wisdom.toString(), inline: true },
        { name: '📊 XP Progress', value: `${user.xp}/${nextLevelXp}`, inline: true },
        { name: '🔄 Rebirths', value: user.rebirthCount.toString(), inline: true }
      );
    
    if (userWithDetails?.bloodline) {
      embed.addFields({
        name: '🐉 Bloodline',
        value: `${userWithDetails.bloodline.name} (${userWithDetails.bloodline.rarity})`,
        inline: false
      });
    }
    
    if (userWithDetails?.faction) {
      embed.addFields({
        name: '🏛️ Faction',
        value: `${userWithDetails.faction.name} - ${user.factionRank}`,
        inline: false
      });
    }
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleCultivateCommand(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    const result = await cultivationService.advanceRealm(user.id);
    
    if (result.success) {
      const embed = new EmbedBuilder()
        .setTitle('🌟 Realm Advancement!')
        .setDescription(`Congratulations! You have advanced to the ${result.user.realm} realm!`)
        .setColor(0xFFD700)
        .addFields(
          { name: 'New Power', value: result.user.power.toString(), inline: true },
          { name: 'Void Crystals Gained', value: result.crystalsGained?.toString() || '0', inline: true }
        )
        .setThumbnail(interaction.user.displayAvatarURL())
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    } else {
      await interaction.reply({ content: result.message, ephemeral: true });
    }
  }
  
  private async handleSparCommand(interaction: any) {
    const opponent = interaction.options.getUser('opponent');
    const attacker = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    const defender = await storage.getUserByDiscordId(opponent.id, interaction.guild.id);
    
    if (!attacker || !defender) {
      await interaction.reply({ content: 'One or both users are not registered.', ephemeral: true });
      return;
    }
    
    if (attacker.id === defender.id) {
      await interaction.reply({ content: 'You cannot spar with yourself!', ephemeral: true });
      return;
    }
    
    const result = await cultivationService.initiateBattle(attacker.id, defender.id, 'spar');
    
    const embed = new EmbedBuilder()
      .setTitle('⚔️ Sparring Match Results')
      .setDescription(result.narrative)
      .setColor(result.result === 'win' ? 0x00FF88 : result.result === 'lose' ? 0xFF4444 : 0xFFD700)
      .addFields(
        { name: 'Attacker', value: `${attacker.username} (${attacker.realm})`, inline: true },
        { name: 'Defender', value: `${defender.username} (${defender.realm})`, inline: true },
        { name: 'Result', value: result.result === 'win' ? 'Victory!' : result.result === 'lose' ? 'Defeat!' : 'Draw!', inline: true }
      );
    
    if (result.xpGained > 0) {
      embed.addFields({ name: 'XP Gained', value: result.xpGained.toString(), inline: true });
    }
    
    if (result.crystalsGained > 0) {
      embed.addFields({ name: 'Crystals Gained', value: result.crystalsGained.toString(), inline: true });
    }
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleFactionCommand(interaction: any) {
    const subcommand = interaction.options.getSubcommand();
    
    switch (subcommand) {
      case 'create':
        await this.handleCreateFaction(interaction);
        break;
      case 'join':
        await this.handleJoinFaction(interaction);
        break;
      case 'leave':
        await this.handleLeaveFaction(interaction);
        break;
      case 'info':
        await this.handleFactionInfo(interaction);
        break;
    }
  }
  
  private async handleCreateFaction(interaction: any) {
    const name = interaction.options.getString('name');
    const description = interaction.options.getString('description') || '';
    
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    if (user.factionId) {
      await interaction.reply({ content: 'You are already in a faction! Leave your current faction first.', ephemeral: true });
      return;
    }
    
    try {
      const faction = await storage.createFaction({
        name,
        description,
        leaderId: user.id,
        serverId: interaction.guild.id,
      });
      
      await storage.joinFaction(user.id, faction.id, 'Leader');
      
      const embed = new EmbedBuilder()
        .setTitle('🏛️ Faction Created!')
        .setDescription(`${name} has been established!`)
        .setColor(0x00D4FF)
        .addFields(
          { name: 'Leader', value: user.username, inline: true },
          { name: 'Description', value: description || 'No description provided', inline: false }
        )
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    } catch (error) {
      await interaction.reply({ content: 'Failed to create faction. The name might already be taken.', ephemeral: true });
    }
  }
  
  private async handleJoinFaction(interaction: any) {
    const factionName = interaction.options.getString('name');
    
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    if (user.factionId) {
      await interaction.reply({ content: 'You are already in a faction!', ephemeral: true });
      return;
    }
    
    const factions = await storage.getFactionsByServer(interaction.guild.id);
    const faction = factions.find(f => f.name.toLowerCase() === factionName.toLowerCase());
    
    if (!faction) {
      await interaction.reply({ content: 'Faction not found.', ephemeral: true });
      return;
    }
    
    await storage.joinFaction(user.id, faction.id, 'Member');
    
    const embed = new EmbedBuilder()
      .setTitle('🏛️ Faction Joined!')
      .setDescription(`Welcome to ${faction.name}!`)
      .setColor(0x00FF88)
      .addFields(
        { name: 'Member', value: user.username, inline: true },
        { name: 'Rank', value: 'Member', inline: true }
      )
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleLeaveFaction(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    if (!user.factionId) {
      await interaction.reply({ content: 'You are not in a faction.', ephemeral: true });
      return;
    }
    
    const faction = await storage.getFactionById(user.factionId);
    await storage.leaveFaction(user.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🏛️ Faction Left')
      .setDescription(`You have left ${faction?.name || 'the faction'}.`)
      .setColor(0xFF4444)
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleFactionInfo(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    if (!user.factionId) {
      await interaction.reply({ content: 'You are not in a faction.', ephemeral: true });
      return;
    }
    
    const faction = await storage.getFactionById(user.factionId);
    if (!faction) {
      await interaction.reply({ content: 'Faction not found.', ephemeral: true });
      return;
    }
    
    const embed = new EmbedBuilder()
      .setTitle(`🏛️ ${faction.name}`)
      .setDescription(faction.description || 'No description provided')
      .setColor(0x00D4FF)
      .addFields(
        { name: 'Members', value: faction.memberCount.toString(), inline: true },
        { name: 'War Points', value: faction.warPoints.toString(), inline: true },
        { name: 'Your Rank', value: user.factionRank || 'Member', inline: true }
      )
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleShopCommand(interaction: any) {
    const items = await storage.getItems();
    const shopItems = items.slice(0, 10); // Show first 10 items
    
    const embed = new EmbedBuilder()
      .setTitle('🏪 Cultivation Shop')
      .setDescription('Purchase items with Void Crystals')
      .setColor(0x00D4FF);
    
    shopItems.forEach(item => {
      embed.addFields({
        name: `${item.name} (${item.rarity})`,
        value: `${item.description}\nPrice: ${item.price} 💎`,
        inline: true
      });
    });
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleInventoryCommand(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    const items = await storage.getUserItems(user.id);
    
    const embed = new EmbedBuilder()
      .setTitle('🎒 Your Inventory')
      .setColor(0x00D4FF);
    
    if (items.length === 0) {
      embed.setDescription('Your inventory is empty. Visit the shop to purchase items!');
    } else {
      items.forEach(userItem => {
        embed.addFields({
          name: `${userItem.item.name} ${userItem.isEquipped ? '(Equipped)' : ''}`,
          value: `${userItem.item.description}\nQuantity: ${userItem.quantity}`,
          inline: true
        });
      });
    }
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleMissionsCommand(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    const missions = await storage.getUserMissions(user.id);
    const activeMissions = missions.filter(m => m.status === 'active');
    
    const embed = new EmbedBuilder()
      .setTitle('📋 Your Missions')
      .setColor(0x00D4FF);
    
    if (activeMissions.length === 0) {
      embed.setDescription('No active missions. New missions will be assigned automatically!');
    } else {
      activeMissions.forEach(userMission => {
        const mission = userMission.mission;
        embed.addFields({
          name: `${mission.title} (${mission.type})`,
          value: `${mission.description}\nReward: ${mission.xpReward} XP, ${mission.crystalReward} 💎`,
          inline: false
        });
      });
    }
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleLeaderboardCommand(interaction: any) {
    const leaderboard = await storage.getLeaderboard(interaction.guild.id, 10);
    
    const embed = new EmbedBuilder()
      .setTitle('🏆 Cultivation Leaderboard')
      .setColor(0xFFD700)
      .setDescription('Top 10 Cultivators by Power');
    
    leaderboard.forEach((user, index) => {
      embed.addFields({
        name: `${index + 1}. ${user.username}`,
        value: `${user.realm} - Level ${user.level}\nPower: ${user.power}`,
        inline: true
      });
    });
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleRebirthCommand(interaction: any) {
    const user = await storage.getUserByDiscordId(interaction.user.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'You are not registered.', ephemeral: true });
      return;
    }
    
    const result = await cultivationService.initiateRebirth(user.id);
    
    if (result.success) {
      const embed = new EmbedBuilder()
        .setTitle('🔄 Rebirth Successful!')
        .setDescription(`You have undergone rebirth! Your journey begins anew with enhanced potential.`)
        .setColor(0x9400D3)
        .addFields(
          { name: 'Rebirth Count', value: result.user.rebirthCount.toString(), inline: true },
          { name: 'Bonus Multiplier', value: `${result.bonusMultiplier}x`, inline: true }
        )
        .setTimestamp();
      
      await interaction.reply({ embeds: [embed] });
    } else {
      await interaction.reply({ content: result.message, ephemeral: true });
    }
  }
  
  private async handleSectMasterCommand(interaction: any) {
    const settings = await storage.getServerSettings(interaction.guild.id);
    
    if (!settings || settings.sectMasterId !== interaction.user.id) {
      await interaction.reply({ content: 'You do not have Sect Master permissions!', ephemeral: true });
      return;
    }
    
    const subcommand = interaction.options.getSubcommand();
    
    switch (subcommand) {
      case 'grant':
        await this.handleGrantLevels(interaction);
        break;
      case 'banish':
        await this.handleBanishUser(interaction);
        break;
      case 'event':
        await this.handleStartEvent(interaction);
        break;
    }
  }
  
  private async handleGrantLevels(interaction: any) {
    const targetUser = interaction.options.getUser('user');
    const levels = interaction.options.getInteger('levels');
    
    const user = await storage.getUserByDiscordId(targetUser.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'Target user is not registered.', ephemeral: true });
      return;
    }
    
    const updatedUser = await storage.updateUser(user.id, {
      level: user.level + levels,
      power: user.power + (levels * 100),
      defense: user.defense + (levels * 100),
      agility: user.agility + (levels * 100),
      wisdom: user.wisdom + (levels * 100),
    });
    
    const embed = new EmbedBuilder()
      .setTitle('👑 Divine Blessing Granted!')
      .setDescription(`The Sect Master has granted ${levels} levels to ${targetUser.displayName}!`)
      .setColor(0xFFD700)
      .addFields(
        { name: 'New Level', value: updatedUser.level.toString(), inline: true },
        { name: 'New Power', value: updatedUser.power.toString(), inline: true }
      )
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleBanishUser(interaction: any) {
    const targetUser = interaction.options.getUser('user');
    
    const user = await storage.getUserByDiscordId(targetUser.id, interaction.guild.id);
    if (!user) {
      await interaction.reply({ content: 'Target user is not registered.', ephemeral: true });
      return;
    }
    
    // Reset user to level 1
    await storage.updateUser(user.id, {
      level: 1,
      realm: 'Connate',
      power: 50,
      defense: 50,
      agility: 50,
      wisdom: 50,
      xp: 0,
      voidCrystals: 0,
    });
    
    const embed = new EmbedBuilder()
      .setTitle('⚡ Divine Punishment!')
      .setDescription(`The Sect Master has banished ${targetUser.displayName} back to the Connate realm!`)
      .setColor(0xFF4444)
      .setTimestamp();
    
    await interaction.reply({ embeds: [embed] });
  }
  
  private async handleStartEvent(interaction: any) {
    const eventType = interaction.options.getString('type');
    
    const embed = new EmbedBuilder()
      .setTitle('🎉 Sect-Wide Event Started!')
      .setColor(0x00FF88)
      .setTimestamp();
    
    switch (eventType) {
      case 'double_xp':
        embed.setDescription('Double XP event is now active! All cultivation activities reward double XP for the next 24 hours!');
        break;
      case 'faction_war':
        embed.setDescription('Faction War has begun! Factions can now battle for supremacy and war points!');
        break;
      case 'treasure_hunt':
        embed.setDescription('Treasure Hunt event is active! Complete missions to find rare treasures!');
        break;
    }
    
    await interaction.reply({ embeds: [embed] });
  }
  
  public async start() {
    if (!this.TOKEN) {
      throw new Error('Discord bot token not provided');
    }
    
    await this.client.login(this.TOKEN);
  }
}

export const bot = new CultivationBot();
